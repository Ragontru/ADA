package com.example.gestionUsuarios2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionUsuarios2Application {

	public static void main(String[] args) {
		SpringApplication.run(GestionUsuarios2Application.class, args);
	}

}
